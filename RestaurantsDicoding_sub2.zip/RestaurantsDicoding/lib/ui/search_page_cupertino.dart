import 'package:RestaurantsDicoding/data/model/restaurant_detail.dart';
import 'package:RestaurantsDicoding/provider/restaurant_provider.dart';
import 'package:RestaurantsDicoding/widget/error_message.dart';
import 'package:RestaurantsDicoding/widget/search_bar_cupertino.dart';
import 'package:RestaurantsDicoding/widget/search_result_list.dart';
import 'package:RestaurantsDicoding/widget/style.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SearchTab extends StatefulWidget {
  static const routeName = '/search_cupertino';

  @override
  _SearchTabState createState() => _SearchTabState();
}

class _SearchTabState extends State<SearchTab> {
  TextEditingController _controller;
  FocusNode _focusNode;
  String _terms = '';

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController()..addListener(_onTextChanged);
    _focusNode = FocusNode();
  }

  @override
  void dispose() {
    _focusNode.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _onTextChanged() {
    setState(() {
      _terms = _controller.text;
    });
    Provider.of<RestaurantProvider>(context, listen: false)
        .fetchSearchRestaurant(_terms);
  }

  Widget _buildSearchBox([BuildContext context]) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          GestureDetector(
            child: Icon(CupertinoIcons.back),
            onTap: () => Navigator.pop(context),
          ),
          Expanded(
            child: SearchBar(
              controller: _controller,
              focusNode: _focusNode,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        color: Styles.scaffoldBackground,
      ),
      child: SafeArea(
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    return Column(
      children: [
        _buildSearchBox(context),
        Expanded(
          child: _buildListView(),
        ),
      ],
    );
  }

  Widget _buildListView() {
    var provider = Provider.of<RestaurantProvider>(context, listen: false);
    var result = provider.fetchSearchRestaurant(_terms);
    return FutureBuilder(
      future: result,
      builder: (context, AsyncSnapshot<dynamic> snapshot) {
        if (snapshot.hasData) {
          return _body(snapshot);
        } else if (snapshot.hasError) {
          return Center(child: Text("${snapshot.error}"));
        }
        return Center(child: CircularProgressIndicator());
      },
    );
  }

  Widget _body(AsyncSnapshot<dynamic> snapshot) {
    var _result = snapshot.data;
    var type = _result.runtimeType.toString();
    print(type);
    switch (type) {
      case "String":
        {
          String _message = _result;
          return ErrorMessage(
            message: _message,
            onClick: () {},
          );
        }
      case "List<Restaurant>":
        {
          List<Restaurant> list = _result;
          return SearchResultListView(suggessionList: list);
        }
      default:
        return ErrorMessage(
          message: "Error, please try again",
          onClick: () {},
        );
    }
  }
}
