import 'package:RestaurantsDicoding/data/model/restaurant.dart';
import 'package:RestaurantsDicoding/data/model/restaurant_detail.dart';
import 'package:RestaurantsDicoding/provider/restaurant_provider.dart';
import 'package:RestaurantsDicoding/ui/search_page_cupertino.dart';
import 'package:RestaurantsDicoding/ui/search_page_material.dart';
import 'package:RestaurantsDicoding/widget/card_restaurant.dart';
import 'package:RestaurantsDicoding/widget/error_message.dart';
import 'package:RestaurantsDicoding/widget/platform_widget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomePage extends StatefulWidget {
  static const routeName = '/home';

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  //
  ResultState _resultState;
  Restaurants _restaurants;
  String _errorMessage;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final provider = Provider.of<RestaurantProvider>(context);
    _restaurants = provider.restaurants;
    _resultState = provider.state;
    _errorMessage = provider.message;
  }

  void actionLoadApi() {
    Provider.of<RestaurantProvider>(context, listen: false)
        .fetchAllRestaurant();
  }

  @override
  Widget build(BuildContext context) {
    actionLoadApi();
    return PlatformWidget(
      androidBuilder: _buildAndroid,
      iosBuilder: _buildIos,
    );
  }

  Widget _buildIos(BuildContext context) {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
        middle: Text('Restaurant List App'),
        trailing: CupertinoButton(
          padding: EdgeInsets.zero,
          onPressed: () {
            Navigator.pushNamed(context, SearchTab.routeName);
          },
          child: Icon(CupertinoIcons.search),
        ),
      ),
      child: _body(),
    );
  }

  Scaffold _buildAndroid(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Restaurant List App"),
        actions: [
          IconButton(
              icon: Icon(Icons.search),
              tooltip: 'Search',
              onPressed: () {
                showSearch(
                    context: context, delegate: SearchViewRestaurantList());
              })
        ],
      ),
      body: _body(),
    );
  }

  List<Restaurant> _getRestaurantList(BuildContext context) {
    return Provider.of<RestaurantProvider>(context, listen: false)
        .restaurants
        .restaurants;
  }

  Widget _body() {
    switch (_resultState) {
      case ResultState.Loading:
        return Center(child: CircularProgressIndicator());
      case ResultState.HasData:
        return ListView.builder(
          itemCount: _restaurants.restaurants.length,
          itemBuilder: (context, index) {
            return Material(
                child: RestaurantCard(item: _restaurants.restaurants[index]));
          },
        );
      case ResultState.NoData:
        return _errorMessageView();
      case ResultState.Error:
        return _errorMessageView();
      default:
        return _errorMessageView();
    }
  }

  Widget _errorMessageView() => ErrorMessage(
        message: _errorMessage,
        onClick: () {
          actionLoadApi();
        },
      );
}
