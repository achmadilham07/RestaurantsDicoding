import 'package:RestaurantsDicoding/data/model/restaurant_detail.dart';
import 'package:RestaurantsDicoding/provider/restaurant_provider.dart';
import 'package:RestaurantsDicoding/widget/error_message.dart';
import 'package:RestaurantsDicoding/widget/search_result_list.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SearchViewRestaurantList extends SearchDelegate<String> {

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
          icon: Icon(Icons.clear),
          onPressed: () {
            query = "";
            showSuggestions(context);
          }),
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: AnimatedIcon(
        progress: transitionAnimation,
        icon: AnimatedIcons.menu_arrow,
      ),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    var provider = Provider.of<RestaurantProvider>(context, listen: false);
    var result = provider.fetchSearchRestaurant(query);

    return FutureBuilder(
      future: result,
      builder: (context, AsyncSnapshot<dynamic> snapshot) {
        if (snapshot.hasData) {
          return _body(snapshot);
        } else if (snapshot.hasError) {
          return Center(child: Text("${snapshot.error}"));
        }
        return Center(child: CircularProgressIndicator());
      },
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return Column();
  }

  Widget _body(AsyncSnapshot<dynamic> snapshot) {
    var _result = snapshot.data;
    var type = _result.runtimeType.toString();
    print(type);
    switch (type) {
      case "String":
        {
          String _message = _result;
          return ErrorMessage(
            message: _message,
            onClick: () {},
          );
        }
      case "List<Restaurant>":
        {
          List<Restaurant> list = _result;
          return SearchResultListView(suggessionList: list);
        }
      default:
        return ErrorMessage(
          message: "Error, please try again",
          onClick: () {},
        );
    }
  }
}
