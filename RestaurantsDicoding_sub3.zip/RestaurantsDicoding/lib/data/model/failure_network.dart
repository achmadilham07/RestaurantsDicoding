class FailureNetwork {
  //
  final String message;

  FailureNetwork(this.message);

  @override
  String toString() => message;
}
