package com.aii.restaurant.RestaurantsDicoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
