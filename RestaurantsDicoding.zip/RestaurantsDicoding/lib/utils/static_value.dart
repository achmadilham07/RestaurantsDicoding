import 'dart:ui';

const colorPrimary = Color(0xff34626c);
const colorPrimaryDark = Color(0xFF839b97);
const colorAccent = Color(0xFFc6b497);
const colorAccentLight = Color(0xFFcfd3ce);
