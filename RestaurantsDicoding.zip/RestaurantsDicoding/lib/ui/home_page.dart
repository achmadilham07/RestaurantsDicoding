import 'package:RestaurantsDicoding/data/restaurant.dart';
import 'package:RestaurantsDicoding/ui/detail_restaurant_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  static const routeName = '/home';

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return _buildIos();
      case TargetPlatform.iOS:
        return _buildIos();
      default:
        return buildAndroid();
    }
  }

  Widget _buildIos() {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
        middle: Text('Restaurant List App'),
      ),
      child: buildFutureBuilder(),
    );
  }

  Scaffold buildAndroid() {
    return Scaffold(
      appBar: AppBar(
        title: Text("Restaurant List App"),
      ),
      body: buildFutureBuilder(),
    );
  }

  FutureBuilder<String> buildFutureBuilder() {
    return FutureBuilder<String>(
      future: loadRestaurant(),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          final restaurant = restaurantFromJson(snapshot.data);
          final restaurantList = restaurant.restaurants;
          return ListView.builder(
            itemCount: restaurantList.length,
            itemBuilder: (context, index) {
              return Material(
                  child: RestaurantCard(item: restaurantList[index]));
            },
          );
        } else if (snapshot.hasError) {
          return Text("${snapshot.error}");
        }
        return Center(child: CircularProgressIndicator());
      },
    );
  }

  Future<String> loadRestaurant() async {
    return await DefaultAssetBundle.of(context)
        .loadString('lib/utils/restaurants.json');
  }
}

class RestaurantCard extends StatelessWidget {
  final RestaurantElement item;

  const RestaurantCard({
    Key key,
    @required this.item,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: () {
        Navigator.pushNamed(context, DetailRestaurant.routeName,
            arguments: item);
      },
      leading: Hero(
        tag: item.id,
        child: Container(
          child: FadeInImage.assetNetwork(
            fit: BoxFit.cover,
            image: item.pictureId,
            placeholder: "images/food-store.png",
          ),
          constraints: BoxConstraints(maxWidth: 100, minWidth: 100),
        ),
      ),
      title: Text(
        item.name,
        style: TextStyle(
          color: Colors.black,
          fontWeight: FontWeight.w600,
          fontSize: 18,
        ),
      ),
      contentPadding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
      isThreeLine: true,
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        mainAxisSize: MainAxisSize.max,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                "images/baseline_grade_black_48dp.png",
                color: Colors.yellow,
                width: 24,
              ),
              Text(item.rating.toString()),
            ],
          ),
          Text(item.city),
        ],
      ),
    );
  }
}
