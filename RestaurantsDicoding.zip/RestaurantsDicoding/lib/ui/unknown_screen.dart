import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class UnknownScreen extends StatelessWidget {
  final titleAppBar = "Invalid Page";
  final message = "Error Page, please go back to previous page.";

  @override
  Widget build(BuildContext context) {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return buildIos();
      case TargetPlatform.iOS:
        return buildIos();
      default:
        return buildAndroid();
    }
  }

  CupertinoPageScaffold buildIos() {
    return CupertinoPageScaffold(
      navigationBar: CupertinoNavigationBar(
        middle: Text(titleAppBar),
      ),
      child: buildMessage(),
    );
  }

  Scaffold buildAndroid() {
    return Scaffold(
      appBar: AppBar(
        title: Text(titleAppBar),
      ),
      body: buildMessage(),
    );
  }

  Center buildMessage() {
    return Center(
      child: Text(message),
    );
  }
}
